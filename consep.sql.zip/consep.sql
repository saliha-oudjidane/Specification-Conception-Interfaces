-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Dim 04 Mars 2018 à 14:58
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `consep`
--

-- --------------------------------------------------------

--
-- Structure de la table `testresult`
--

CREATE TABLE IF NOT EXISTS `testresult` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `combinaison` int(3) NOT NULL,
  `reponse` int(11) NOT NULL,
  `temps` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Contenu de la table `testresult`
--

INSERT INTO `testresult` (`id`, `userid`, `combinaison`, `reponse`, `temps`) VALUES
(1, 1, 1, 0, 1),
(2, 1, 0, 0, 6),
(3, 2, 0, 5, 10),
(4, 5, 0, 4, 7),
(5, 5, 1, 2, 5),
(6, 5, 1, 5, 185),
(7, 5, 0, 6, 5),
(8, 2, 4, 3, 26),
(9, 2, 12, 2, 188),
(10, 2, 30, 2, 4),
(11, 4, 0, 5, 3),
(12, 4, 4, 6, 3),
(13, 4, 12, 8, 4),
(14, 4, 30, 8, 3),
(15, 3, 0, 4, 12),
(16, 3, 4, 5, 4),
(17, 3, 12, 3, 3),
(18, 3, 30, 4, 2),
(19, 6, 0, 1, 6),
(20, 6, 4, 5, 3),
(21, 6, 12, 4, 4),
(22, 6, 30, 1, 3),
(23, 7, 9, 5, 7),
(24, 7, 4, 5, 3),
(25, 7, 12, 5, 7),
(26, 7, 30, 5, 13),
(27, 9, 9, 2, 12),
(28, 9, 4, 5, 3),
(29, 9, 12, 2, 4),
(30, 9, 30, 2, 3),
(31, 8, 9, 2, 8),
(32, 8, 4, 2, 3),
(33, 8, 12, 0, 2),
(34, 8, 30, 0, 1),
(35, 10, 9, 2, 4),
(36, 10, 4, 2, 6),
(37, 10, 12, 0, 3),
(38, 10, 30, 5, 3),
(39, 11, 9, 5, 3),
(40, 11, 4, 5, 3),
(41, 11, 12, 2, 158),
(42, 11, 30, 6, 14),
(43, 12, 9, 2, 27),
(44, 12, 4, 2, 3),
(45, 12, 12, 6, 2),
(46, 12, 30, 8, 3),
(47, 13, 9, 2, 7),
(48, 13, 4, 5, 4),
(49, 13, 12, 9, 3),
(50, 13, 30, 5, 11),
(51, 14, 9, 3, 7),
(52, 14, 4, 4, 4),
(53, 14, 12, 3, 4),
(54, 14, 30, 3, 3),
(55, 15, 9, 3, 3),
(56, 15, 4, 4, 4),
(57, 15, 12, 3, 2),
(58, 15, 30, 3, 10),
(59, 16, 9, 0, 36),
(60, 16, 4, 3, 3),
(61, 16, 12, 4, 3),
(62, 16, 30, 2, 3),
(63, 16, 11, 3, 139),
(64, 16, 21, 3, 12);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(250) NOT NULL,
  `etat` int(1) NOT NULL DEFAULT '0',
  `imagenumero` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `sexe` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `nom`, `etat`, `imagenumero`, `age`, `sexe`) VALUES
(1, 'mok', 1, 4, 36, 'M'),
(2, 'aa', 1, 3, 52, 'M'),
(3, 'kahina', 1, 3, 32, 'F'),
(4, 'rr', 1, 3, 25, 'M'),
(5, 'gg', 1, 3, 25, 'M'),
(6, 'hh', 1, 3, 0, 'M'),
(7, 'kkk', 1, 3, 20, 'F'),
(8, 'ffgg', 1, 3, 85, 'M'),
(9, 'ffgg', 1, 3, 85, 'M'),
(10, 'ggggg', 1, 3, 85, 'M'),
(11, 'tttt', 1, 3, 15, 'F'),
(12, 'mmm', 1, 3, 25, 'M'),
(13, 'III', 1, 3, 0, 'F'),
(14, 'BESACIER', 1, 3, 0, 'M'),
(15, 'utilisateur1', 1, 3, 0, 'M'),
(16, 'kkll', 0, 5, 0, 'F');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
